import discord
from discord.ext import commands
import sqlite3
import asyncio

intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

# Conectar ao banco de dados SQLite
conn = sqlite3.connect("bot_data.db")
cursor = conn.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        logs_channel INTEGER,
        form_active INTEGER DEFAULT 1
    )
""")
conn.commit()

# Garante que sempre exista uma linha na tabela settings
cursor.execute("SELECT COUNT(*) FROM settings")
if cursor.fetchone()[0] == 0:
    cursor.execute("INSERT INTO settings (logs_channel, form_active) VALUES (?, ?)", (None, 1))
    conn.commit()

# ID do canal de logs (definido manualmente)
LOGS_CHANNEL_ID = 1324179575307243521  # Substitua pelo ID real do canal de logs

# Lista de perguntas do formulário
perguntas = [
    "Nome IC:", "Nome OOC:", "RG/IDF IC:", "Nível e horas jogadas:", "Número de celular OOC:", "Discord:",
    "Já atuou em outra organização? Se sim, qual e por que saiu?",
    "Como você lida com civis que não colaboram com a Milícia?",
    "O que você entende por Milícia dentro do RP?",
    "Por que você deseja ingressar na Milícia?",
    "Um policial aborda você e pergunta sobre sua relação com a Milícia. Como reagiria?",
    "O que é Power Gaming (PG)?", "O que é Deathmatch (DM)?",
    "O que é Character Kill (CK) e quando ele ocorre?", "O que é Combat login (CL)?",
    "O que é Roleplay de Ferimentos e como funciona?",
    "Você vê um jogador quebrando regras. O que faz?",
    "Um novo comete um erro de RP. Como agiria?",
    "Como explicar para um novo jogador a importância de seguir a Bíblia RP?",
    "Você está em um problema que pode levar para o OOC. Como resolveria?"
]

# Comando para iniciar o formulário
@bot.command()
async def form(ctx):
    # Verifica se o formulário está ativo
    cursor.execute("SELECT form_active FROM settings")
    row = cursor.fetchone()

    if row is None or row[0] == 0:
        await ctx.reply("O formulário está desativado no momento.", ephemeral=True)
        return

    guild = ctx.guild
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(view_channel=False),
        ctx.author: discord.PermissionOverwrite(view_channel=True, send_messages=True)
    }

    ticket_channel = await guild.create_text_channel(name=f"form-{ctx.author.name}", overwrites=overwrites)
    await ctx.reply(f"Seu formulário foi iniciado em {ticket_channel.mention}.", ephemeral=True)

    respostas = []

    async def perguntar(index=0):
        if index < len(perguntas):
            embed = discord.Embed(title=f"Pergunta {index + 1}", description=perguntas[index], color=discord.Color.blue())
            await ticket_channel.send(embed=embed)

            def check(msg):
                return msg.author == ctx.author and msg.channel == ticket_channel

            msg = await bot.wait_for("message", check=check)
            respostas.append(msg.content)
            await perguntar(index + 1)
        else:
            close_button = discord.ui.Button(label="Fechar Ticket", style=discord.ButtonStyle.red, custom_id="close_ticket")

            async def close_callback(interaction):
                await interaction.channel.delete()

            close_button.callback = close_callback
            view = discord.ui.View()
            view.add_item(close_button)

            await ticket_channel.send(embed=discord.Embed(title="Formulário concluído!", description="Você concluiu o formulário.", color=discord.Color.green()), view=view)

            # Envia as respostas para o canal de logs
            log_channel = bot.get_channel(LOGS_CHANNEL_ID)
            if log_channel:
                respostas_msg = "\n".join([f"**{perguntas[i]}** {respostas[i]}" for i in range(len(respostas))])
                log_embed = discord.Embed(
                    title="Novo formulário respondido",
                    description=f"**Respondido por:** {ctx.author.mention}\n\n{respostas_msg}",
                    color=discord.Color.purple()
                )
                await log_channel.send(embed=log_embed)

            # Fecha o ticket em 5 segundos
            await asyncio.sleep(5)
            await ticket_channel.delete()

    await perguntar()

# Comando para ativar o formulário
@bot.command()
@commands.has_permissions(administrator=True)
async def onform(ctx):
    cursor.execute("UPDATE settings SET form_active = 1")
    conn.commit()
    await ctx.reply("Formulário ativado. Agora os jogadores podem usá-lo.", ephemeral=True)

# Comando para desativar o formulário
@bot.command()
@commands.has_permissions(administrator=True)
async def offform(ctx):
    cursor.execute("UPDATE settings SET form_active = 0")
    conn.commit()
    await ctx.reply("Formulário desativado. Ninguém poderá usá-lo até que um administrador o ative novamente.", ephemeral=True)

bot.run("MTMyNjE5NjMxMjUzMzYzMTAxNg.Geh7iA.UCA1_go3sdTIMPZcJL6LuNIEOWyiZ7AMvks1aI")